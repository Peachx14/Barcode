const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }
})

const fail = (message, status = 400) => json({ error: message }, status)

async function readBody(request) {
  try { return await request.json() } catch { return null }
}

export async function onRequest(context) {
  const { request, env } = context
  if (!env.DB) return fail('ยังไม่ได้เชื่อม D1 Database: เพิ่ม D1 binding ชื่อ DB ใน Cloudflare Pages Settings แล้ว Deploy ใหม่', 503)

  const url = new URL(request.url)
  const path = url.pathname.replace(/^\/api\/?/, '').replace(/\/$/, '')
  const method = request.method.toUpperCase()

  try {
    if (method === 'GET' && path === 'health') {
      const result = await env.DB.prepare('SELECT 1 AS ok').first()
      return json({ ok: result?.ok === 1, service: 'CartonFlow API', database: 'connected' })
    }

    if (method === 'GET' && path === 'cartons') {
      const { results: cartonRows } = await env.DB.prepare(
        'SELECT id, carton_number, carton_barcode, status, created_at, created_by, closed_at FROM cartons ORDER BY created_at DESC'
      ).all()
      const { results: itemRows } = await env.DB.prepare(
        'SELECT id, carton_id, product_barcode, scanned_product_barcode, quantity, created_at, created_by FROM carton_items ORDER BY created_at ASC'
      ).all()
      const byCarton = new Map()
      for (const item of itemRows || []) {
        const list = byCarton.get(item.carton_id) || []
        list.push(item)
        byCarton.set(item.carton_id, list)
      }
      return json((cartonRows || []).map(carton => ({ ...carton, carton_items: byCarton.get(carton.id) || [] })))
    }

    if (method === 'POST' && path === 'cartons') {
      const body = await readBody(request)
      const carton_number = String(body?.carton_number || '').trim()
      const carton_barcode = String(body?.carton_barcode || '').trim()
      if (!carton_number || !carton_barcode) return fail('กรุณากรอกเลขลังและบาร์โค้ดลัง')
      const id = crypto.randomUUID()
      await env.DB.prepare(
        "INSERT INTO cartons (id, carton_number, carton_barcode, status, created_by) VALUES (?, ?, ?, 'กำลังบันทึก', 'ไม่ระบุ')"
      ).bind(id, carton_number, carton_barcode).run()
      return json({ id, carton_number, carton_barcode, status: 'กำลังบันทึก' }, 201)
    }

    if (method === 'POST' && path === 'items') {
      const body = await readBody(request)
      const carton_id = String(body?.carton_id || '').trim()
      const barcode = String(body?.barcode || '').trim()
      const quantity = Number(body?.quantity)
      if (!carton_id || !barcode || !Number.isSafeInteger(quantity) || quantity < 1) return fail('กรุณาตรวจสอบลัง บาร์โค้ด และจำนวนสินค้า')
      const carton = await env.DB.prepare('SELECT status FROM cartons WHERE id = ?').bind(carton_id).first()
      if (!carton) return fail('ไม่พบลังที่เลือก', 404)
      if (carton.status !== 'กำลังบันทึก') return fail('ลังนี้ปิดแล้ว ไม่สามารถเพิ่มสินค้าได้', 409)
      const id = crypto.randomUUID()
      await env.DB.prepare(
        "INSERT INTO carton_items (id, carton_id, product_barcode, scanned_product_barcode, quantity, created_by) VALUES (?, ?, ?, ?, ?, 'ไม่ระบุ')"
      ).bind(id, carton_id, barcode, barcode, quantity).run()
      return json({ id, carton_id, product_barcode: barcode, scanned_product_barcode: barcode, quantity }, 201)
    }

    const closeMatch = path.match(/^cartons\/([0-9a-f-]+)\/close$/i)
    if (method === 'POST' && closeMatch) {
      const result = await env.DB.prepare(
        "UPDATE cartons SET status = 'ปิดลัง', closed_at = datetime('now') WHERE id = ? AND status = 'กำลังบันทึก'"
      ).bind(closeMatch[1]).run()
      if (!result.meta?.changes) return fail('ไม่พบลัง หรือ ลังถูกปิดไปแล้ว', 409)
      return json({ ok: true, id: closeMatch[1], status: 'ปิดลัง' })
    }

    return fail('ไม่พบ API endpoint', 404)
  } catch (error) {
    const message = String(error?.message || 'เกิดข้อผิดพลาดจากฐานข้อมูล')
    if (/UNIQUE constraint failed/i.test(message)) return fail('เลขลังหรือบาร์โค้ดลังนี้มีอยู่แล้ว', 409)
    if (/ลังนี้ปิดแล้ว/i.test(message)) return fail('ลังนี้ปิดแล้ว ไม่สามารถแก้ไขรายการสินค้าได้', 409)
    return fail(message, 500)
  }
}
